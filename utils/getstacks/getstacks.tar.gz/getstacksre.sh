#!/bin/bash

scriptdir=`dirname "$0"`
gdbpackage="gdb-8.2.1-x86_64.tar.gz"
gdbpackageloc="${scriptdir}/${gdbpackage}"
containercommand=docker
pidsfile=pids.txt.stacks
stackdir=/tmp/getstacks

if [ ! -z $1 ] ; then
  containercommand=$1
fi

cat > podstacks.sh <<EOF
ps -ef | grep "osh" | grep -v grep | grep -v defunct | grep -v oshwrapper > ${pidsfile}
for pid in \$(ps -ef | grep "osh" | grep -v grep | grep -v defunct | grep -v oshwrapper | awk '{print \$2}'); do
  isconductor=\`cat ${pidsfile} | grep \$pid | head -1 | grep 'osh -f' | wc -l\`
  if [ \$isconductor -eq 1 ] ; then
    filename=\$pid.conductor.txt.stacks
  else
    type=\`cat ${pidsfile} | grep \$pid | head -1 | grep -v grep | awk '{print \$19}'\`
    if [ "\$type" != "ORCHESTRATE_Section_Leader" ] ; then
      opname=\`cat ${pidsfile} | grep \$pid | head -1 | grep -v grep | awk '{print \$20}'\`
      filename=\$pid.\$type.\$opname.txt.stacks
    else
      filename=\$pid.\$type.txt.stacks
    fi
  fi
  echo "Dumping stack for osh \$pid to \$filename"
  ./gstack \$pid > \$filename
done
EOF

runtimebase="ds-px-runtime"
runtimepods=`${containercommand} ps | grep ${runtimebase} | awk '{print $1}'`

if [ "$runtimepods" = "" ] ; then
  echo "Runtime pods not found with name ${runtimebase}"
  exit
fi

echo "Gathering stacks from following runtime pods:"
echo "${runtimepods}"

for runtimepod in $runtimepods ; do
  echo "Creating temp directory for stacks ${stackdir}"
  ${containercommand} exec ${runtimepod} bash -c "mkdir -p ${stackdir} && rm -f ${stackdir}/*"
  echo "Copying ${gdbpackage} to ${runtimepod}"
  ${containercommand} cp ${gdbpackageloc} ${runtimepod}:${stackdir}/${gdbpackage}
  echo "Copying podstacks.sh to ${runtimepod}"
  ${containercommand} cp podstacks.sh ${runtimepod}:${stackdir}/podstacks.sh
  echo "Collecting stack traces"
  ${containercommand} exec ${runtimepod} bash -c "cd ${stackdir} && tar xfz ${gdbpackage} && chmod 755 podstacks.sh && ./podstacks.sh && tar cfz ${runtimepod}.stacks.tgz *.stacks"
  echo "Copying ${runtimepod}.stacks.tgz locally"
  ${containercommand} cp ${runtimepod}:${stackdir}/${runtimepod}.stacks.tgz ${runtimepod}.stacks.tgz
done

echo "Done"
